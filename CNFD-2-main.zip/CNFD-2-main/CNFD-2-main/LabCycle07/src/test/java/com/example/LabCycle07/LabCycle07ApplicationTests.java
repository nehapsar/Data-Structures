package com.example.LabCycle07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabCycle07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
